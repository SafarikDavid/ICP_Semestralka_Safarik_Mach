ReadMe_20180310_KickAir8P_UVUnwrapped_Stanford_Bunny_OBJ-JPG.txt
--------------------------------------------------------

File List:

20180310_KickAir8P_UVUnwrapped_Stanford_Bunny.obj
20180310_KickAir8P_UVUnwrapped_Ceramic_Stanford_Bunny.mtl
bunnystanford_res1_UVmapping3072_g005c.jpg
bunnystanford_res1_UVmapping3072_TerraCotta_g001c.jpg
BunnyEye001_g003.png


All contents of this zip file are CC0 2018 KickAir8P - Public Domain with the following exception:


Although the Stanford Bunny ( https://en.wikipedia.org/wiki/Stanford_bunny ) has been made freely available for non-commercial use, it is not public domain.

-----30-----
